#include<stdio.h>
#include<time.h>
#include<conio.h>
#include<string.h>
#include<stdlib.h>
//user defined function declarations(starting)
void space()
{
    printf("\t\t\t\t\t\t\t\t    ");   //to print text in middle of screen
}
int menu() //to print MENU
{
    int choice;
    system("cls");
    printf("\n\n");
    space();
    printf("MENU:\t");
    times();
    printf("\n\n");
    space();
    printf("1-Create New Account\n");
    space();
    printf("2-Withdraw Cash\n");
    space();
    printf("3-Deposit Cash\n");
    space();
    printf("4-Cash Fill\n");
    space();
    printf("5-Account Summary\n");
    space();
    printf("6-EXIT\n\n");
    space();
    printf("Enter Your Choice: ");
    scanf("%d",&choice);
    return choice;
}
void times()  //to display time
{
    time_t t;
    time(&t);
    printf("\t\t  %s",ctime(&t));
}
void fileerror()  //when file is not opened, this function comes into action
{
    space();
    printf("Error!! Information Not Saved!!\n");
    space();
    printf("Try Again!!\n");
    space();
    printf("Press Any Key To Continue!!");
    getchar();
}
void wrong() //when user enters wrong user name/password this function comes into action
{
    printf("\n\n");
    space();
    printf("Wrong Username or Passcode!!\n");
    space();
    printf("Press Any Key To Continue!!");
    getchar();
    getchar();
}
void exist()  //when user account does not exists, this function comes into action
{
    printf("\n\n");
    space();
    printf("Account Doesnot Exist!!\n");
    space();
    printf("Create New Account!!\n");
    printf("\n\n");
    space();
    printf("Press Any Key To Continue!!");
    printf("\n\n");
    getchar();
    getchar();
}
void multiple()  //when deposit/withdraw amount is not multiple of 500, this function runs
{
    printf("\n");
    space();
    printf("Invalid Amount Entered!!\n");
    space();
    printf("Amount Should Be Multiple Of 500!!\n");
    printf("\n\n");
    space();
    printf("Press Any Key To Re-enter!!");
    getchar();
    getchar();
}
void username()  //when entered user name is already in use,this function runs
{
    space();
    printf("Username Not Available!!\n");
    space();
    printf("Try Another Username!!\n");
    printf("\n\n");
    space();
    printf("Press Any Key To Re-enter!!\n");
    getchar();
    getchar();
}
struct information //structure data type, stores account information
{
    char fullname[20];
    long long int number;
    char username[20];
    int passcode;
    int deposit;
    int withdraw;
    int addcash;
};
struct bank //structure data type,stores bank information
{
    char bankname[5];
    int branchid;
    int bankamount;
    int available;
};
//user defined function declaration(ending)
int main()  //main function starting
{
    //global variable declaration(starting)
    int option,code;
    char name[20];
    char bank[4]="HBL";
    int id;
    struct information account;
    struct bank data;
    account.deposit=0;
    account.withdraw=0;
    account.addcash=0;
    data.branchid=2595;
    data.bankamount=0;
    data.available=0;
    FILE*ptr; //file pointer
    menu:
    option=menu();
    switch(option) //use of switch statement to navigate through option available
    {
        case 1:  //for creating new account
        {
            system("cls");
            printf("\n\n");
            space();
            printf("\t\t");
            times();
            space();
            printf("Enter Name: ");
            scanf("%s",&account.fullname);
            space();
            printf("Enter Contact Number: ");
            scanf("%lld",&account.number);
            newaccount:
            printf("\n");
            space();
            printf("Enter Username: ");
            scanf("%s",&account.username);
            space();
            printf("Re-enter Username: ");
            scanf("%s",&name);
            printf("\n\n");
            space();
            printf("Enter Passcode: ");
            scanf("%d",&account.passcode);
            space();
            printf("Re-enter Passcode: ");
            scanf("%d",&code);
            printf("\n");
            ptr=fopen(account.username,"r");//opening file in read mode,read mode does not creates a new file,it opens existing file
                if(ptr!=0)
                {
                    username();  //if file opens,it means user name already exists
                    goto newaccount;
                    break;
                }
                else
                {
                    if(account.passcode==code&&strcmp(account.username,name)==0)
                    {
                        space();
                        printf("Your Account Has Been Created Successfully!!\n");
                        deposit:
                        printf("\n");
                        space();
                        printf("Deposit Some Money: ");
                        scanf("%d",&account.deposit);
                            if(account.deposit%500==0&&account.deposit!=0)
                            {
                                printf("\n");
                                space();
                                printf("Money Deposited Successfully!!\n");
                                space();
                                printf("Account Balance: %d Rs",account.deposit);
                                printf("\n\n");
                                space();
                                printf("Date Saved Successfully!!\n\n\n");
                                space();
                                printf("Press Any Key To Continue!!\n\n\n");
                            }
                            else
                            {
                                multiple();
                                goto deposit;
                                break;
                            }
                    }
                    else
                    {
                        printf("\n");
                        space();
                        printf("Entered Credentials Doesn't Match!!\n");
                        space();
                        printf("Press Any Key To Re-enter!!");
                        getchar();
                        getchar();
                        goto newaccount;
                        break;
                    }
                }
        ptr=fopen(account.username,"w"); //opening file in write mode.
            if(ptr==NULL)
            {
                fileerror();
                goto newaccount;
                break;
            }
            else
            {
                fprintf(ptr,"%s\n",account.fullname);  //printing all data in file
                fprintf(ptr,"%lld\n",account.number);
                fprintf(ptr,"%s\n",account.username);
                fprintf(ptr,"%d\n",account.passcode);
                fprintf(ptr,"%d\n",account.deposit);
                fprintf(ptr,"%d\n",account.withdraw);
                fprintf(ptr,"%d\n",account.addcash);
                fclose(ptr);
            }
            getchar();
            getchar();
            goto menu;
            break;
        }
        case 2: //withdrawing cash from account
        {
            withdraw:
            system("cls");
            printf("\n\n\n");
            space();
            printf("Enter Username: ");
            scanf("%s",&name);
            space();
            printf("Enter Passcode: ");
            scanf("%d",&code);
            ptr=fopen(name,"rb");//opening file in rb mode
                if(ptr==NULL) //if file does not opens then user does not exists
                {
                    exist();
                    goto menu;
                    break;
                }
                else
                {
                    fscanf(ptr,"%s",&account.fullname);  //taking data from file and storing it in variables
                    fscanf(ptr,"%lld",&account.number);
                    fscanf(ptr,"%s",&account.username);
                    fscanf(ptr,"%d",&account.passcode);
                    fscanf(ptr,"%d",&account.deposit);
                    fscanf(ptr,"%d",&account.withdraw);
                    fscanf(ptr,"%d",&account.addcash);
                    fclose(ptr);
                    if(account.passcode==code&&strcmp(account.username,name)==0) //comparing user name and pass code with data entered while creating account
                    {
                        printf("\n\n");
                        space();
                        printf("Welcome--%s",strupr(account.fullname));
                        times();
                        printf("\n");
                        space();
                        printf("Account Balance: %d Rs\n",account.deposit+account.addcash-account.withdraw);
                        draw:
                        printf("\n\n");
                        space();
                        printf("Enter Amount To Withdraw: ");
                        scanf("%d",&account.withdraw);
                        printf("\n");
                        if(account.withdraw>account.deposit+account.addcash)
                        {
                            space();
                            printf("Amount Exceeds The Account Balance!!\n");
                            space();
                            printf("Press Any Key To Re-enter!!");
                            getchar();
                            getchar();
                            goto draw;
                            break;
                        }
                        else
                        {
                            if(account.withdraw%500==0&&account.deposit!=0)
                            {
                                printf("\n\n");
                                space();
                                printf("Amount Withdrawn Successfully!!\n");
                                space();
                                printf("Account Balance: %d Rs\n",account.deposit-account.withdraw+account.addcash);
                                printf("\n");
                                space();
                                printf("Press An Key To Continue!!");
                                getchar();
                                getchar();
                            }
                            else
                            {
                                multiple();
                                goto draw;
                                break;
                            }
                        }
                    }
                    else
                    {
                        wrong();
                        goto withdraw;
                        break;
                    }
                }
            ptr=fopen(account.username,"w"); //opening file to print data in file
            if(ptr==NULL)
            {
                fileerror();
                goto withdraw;
                break;
            }
            else
            {
                fprintf(ptr,"%s\n",account.fullname);
                fprintf(ptr,"%lld\n",account.number);
                fprintf(ptr,"%s\n",account.username);
                fprintf(ptr,"%d\n",account.passcode);
                fprintf(ptr,"%d\n",account.deposit);
                fprintf(ptr,"%d\n",account.withdraw);
                fclose(ptr);
            }
            goto menu;
            break;
        }
        case 3: //depositing money in user account
        {
            addcash:
            system("cls");
            printf("\n\n");
            space();
            printf("Enter Username: ");
            scanf("%s",&name);
            space();
            printf("Enter Passcode: ");
            scanf("%d",&code);
            ptr=fopen(name,"rb");
                if(ptr==NULL) //file does not open = user does not exists
                {
                    exist();
                    goto menu;
                    break;
                }
                else
                {
                    fscanf(ptr,"%s",&account.fullname); //taking data from file and storing it in variables
                    fscanf(ptr,"%lld",&account.number);
                    fscanf(ptr,"%s",&account.username);
                    fscanf(ptr,"%d",&account.passcode);
                    fscanf(ptr,"%d",&account.deposit);
                    fscanf(ptr,"%d",&account.withdraw);
                    fclose(ptr);
                        if(account.passcode==code&&strcmp(account.username,name)==0) //compaing entered credentials
                        {
                            printf("\n\n");
                            space();
                            printf("Welcome--%s",strupr(account.fullname));
                            times();
                            printf("\n");
                            space();
                            printf("Account Balance: %d Rs\n",account.deposit+account.addcash-account.withdraw);
                            add:
                            printf("\n\n");
                            space();
                            printf("Enter Amount To Deposit: ");
                            scanf("%d",&account.addcash);
                                if(account.addcash%500==0&&account.deposit!=0)
                                {
                                    printf("\n");
                                    space();
                                    printf("Money Deposited Successfully!!\n");
                                    space();
                                    printf("Account Balance: %d Rs",account.deposit+account.addcash-account.withdraw);
                                    printf("\n\n");
                                    space();
                                    printf("Press Any Key To Continue!!\n\n\n");
                                    getchar();
                                    getchar();
                                }
                                else
                                {
                                    multiple();
                                    goto add;
                                    break;
                                }
                        }
                        else
                        {
                            wrong();
                            goto addcash;
                            break;
                        }
                }
            ptr=fopen(account.username,"w");//savinng data in file in write mode
            if(ptr==NULL)//if file does not opens, than data is not saved successfully
            {
                fileerror();
                goto addcash;
                break;
            }
            else
            {
                fprintf(ptr,"%s\n",account.fullname); //printing data in file
                fprintf(ptr,"%lld\n",account.number);
                fprintf(ptr,"%s\n",account.username);
                fprintf(ptr,"%d\n",account.passcode);
                fprintf(ptr,"%d\n",account.deposit);
                fprintf(ptr,"%d\n",account.withdraw);
                fprintf(ptr,"%d\n",account.addcash);
                fclose(ptr);
            }
            goto menu;
            break;
        }
        case 4: //adding cash in machine
        {
            cashfill:
            system("cls");
            printf("\n\n");
            space();
            printf("Enter Bank Name: ");  // bank name is "HBL" ,declared when initialized
            scanf("%s",&data.bankname);
            space();
            printf("Enter Branch ID: ");  //branch code is "2595" , declared when initialized
            scanf("%d",&id);
            printf("\n\n");
            ptr=fopen("HBL.txt","r");
                if(ptr==NULL) // file not opened/exists
                {
                    space();
                    printf("An Error Occurred!!\n\n");
                    space();
                    printf("Press Any Key To Continue!!\n");
                    getchar();
                    getchar();
                    goto menu;
                    break;
                }
                else
                {
                    fscanf(ptr,"%s",&data.bankname); //taking data from existing file
                    fscanf(ptr,"%d",&data.branchid);
                    fscanf(ptr,"%d",&data.bankamount);
                    fscanf(ptr,"%d",&data.available);
                    fclose(ptr);
                    if(data.branchid==id&&strcmp(bank,data.bankname)==0) //comparing data entered with data in file
                    {
                        space();
                        printf("Access Granted!!\n");
                        printf("\n\n");
                        space();
                        printf("Cash Available: %d",data.available+account.deposit+account.addcash-account.withdraw);
                        bankcashfill:
                        printf("\n\n");
                        space();
                        printf("Enter Amount: ");
                        scanf("%d",&data.bankamount);
                            if(data.bankamount%500!=0)
                            {
                                printf("\n\n");
                                space();
                                printf("Entered Amount Should Be Multiple Of 500!!\n");
                                space();
                                printf("Try Again!!\n");
                                space();
                                printf("Press Any Key To Re-enter!!\n");
                                getchar();
                                getchar();
                                goto bankcashfill;
                                break;
                            }
                        printf("\n\n");
                        space();
                        printf("Cash Filled Successfully!!\n");
                        space();
                        printf("Cash Available: %d\n",data.available=data.bankamount+data.available+account.deposit+account.addcash-account.withdraw);
                        printf("\n\n");
                        space();
                        printf("Press Any Key To Continue!!");
                        getchar();
                        getchar();
                    }
                    else //if branch code & name does not match, access is revoked
                    {
                        space();
                        printf("Invalid Details!!\n");
                        space();
                        printf("Access Revoked!!\n");
                        printf("\n\n");
                        space();
                        printf("Press Any Key To Continue!!");
                        getchar();
                        getchar();
                    }
                }
                ptr=fopen("HBL.txt","w"); //creating new "HBL.TXT" file for saving bank data
                if(ptr==NULL) //if file does not opens
                {
                    fileerror();
                    goto cashfill;
                    break;
                }
                else
                {
                    fprintf(ptr,"%s\n",data.bankname);  //printing data in file
                    fprintf(ptr,"%d\n",data.branchid);
                    fprintf(ptr,"%d\n",data.bankamount);
                    fprintf(ptr,"%d\n",data.available);
                    fclose(ptr);
                }
            goto menu;
            break;
        }
        case 5:  //account summary
        {
            system("cls");
            summary:
            printf("\n\n");
            space();
            printf("Enter Username: ");
            scanf("%s",&name);
            space();
            printf("Enter Passcode: ");
            scanf("%d",&code);
            ptr=fopen(name,"rb");
                if(ptr==NULL) //file does not opens, account does not exists
                {
                    exist();
                    goto menu;
                    break;
                }
                else
                {
                    fscanf(ptr,"%s",&account.fullname);    //taking data from file
                    fscanf(ptr,"%lld",&account.number);
                    fscanf(ptr,"%s",&account.username);
                    fscanf(ptr,"%d",&account.passcode);
                    fscanf(ptr,"%d",&account.deposit);
                    fscanf(ptr,"%d",&account.withdraw);
                    fscanf(ptr,"%d",&account.addcash);
                    fclose(ptr);
                        if(account.passcode==code&&strcmp(account.username,name)==0) //matching entered credentials
                        {
                            printf("\n\n");
                            space();
                            printf("Welcome--%s",strupr(account.fullname));
                            times();
                            printf("\n");
                            space();
                            printf("Name: %s\n",account.fullname);
                            space();
                            printf("Contact: %lld",account.number);
                            printf("\n\n");
                            space();
                            printf("Account Balance: %d Rs\n",account.deposit-account.withdraw+account.addcash);
                            printf("\n");
                            space();
                            printf("Initial Deposit: %d Rs\n",account.deposit);
                            printf("\n");
                            space();
                            printf("Last Deposit: %d Rs\n",account.addcash);
                            space();
                            printf("Last Withdrawal: %d Rs",account.withdraw);
                            printf("\n\n");
                            space();
                            printf("Press Any Key To Continue!!\n\n\n");
                            getchar();
                            getchar();
                        }
                        else
                        {
                            wrong();
                            goto summary;
                            break;
                        }
                }
            goto menu;
            break;
        }
        case 6: //exiting program
        {
            exit(1);
            break;
        }
        default:  //default case
        {
            printf("\n");
            space();
            printf("Wrong Choice!!\n");
            space();
            printf("Please Choose Between 1 & 6!!\n");
            space();
            printf("Press Any Key To Continue!!\n\n");
            getchar();
            getchar();
            goto menu;
            break;
        }
    }
    return 0;
}
